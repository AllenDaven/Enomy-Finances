package com.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import com.model.User;

@WebServlet("/admin")
public class AdminServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<User> users = getUsersFromDatabase(); // Implement this method to retrieve users from the database
        request.setAttribute("users", users);
        RequestDispatcher rd = request.getRequestDispatcher("/admin.jsp");
        rd.forward(request, response);
    }

    private List<User> getUsersFromDatabase() {
        // TODO: Implement this method to retrieve users from the database
        // Your JDBC code to fetch users from the database goes here
        return null; // Replace this with the actual list of users retrieved from the database
    }
}

