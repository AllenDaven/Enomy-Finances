//Currency Converter
function convertCurrency() {
    const fromCurrency = document.getElementById("fromCurrency").value;
    const toCurrency = document.getElementById("toCurrency").value;
    const amount = parseFloat(document.getElementById("amount").value);

    const exchangeRate = getExchangeRate(fromCurrency, toCurrency);
    const convertedAmount = amount * exchangeRate;

    document.getElementById("result").innerText = `${amount} ${fromCurrency} = ${convertedAmount.toFixed(2)} ${toCurrency}`;
}

function getExchangeRate(fromCurrency, toCurrency) {
  
    const exchangeRates = {
        GBP: { USD: 1.38, EUR: 1.16, BRL: 7.66, JPY: 152.36, TRY: 14.72 },
        USD: { GBP: 0.72, EUR: 0.84, BRL: 5.26, JPY: 104.74, TRY: 10.15 },
        EUR: { GBP: 0.86, USD: 1.19, BRL: 6.25, JPY: 125.16, TRY: 12.11 },
        BRL: { GBP: 0.13, USD: 0.19, EUR: 0.16, JPY: 19.87, TRY: 1.92 },
        JPY: { GBP: 0.0066, USD: 0.0095, EUR: 0.008, BRL: 0.0503, TRY: 0.097 },
        TRY: { GBP: 0.068, USD: 0.098, EUR: 0.082, BRL: 0.52, JPY: 10.33 }
    };

    return exchangeRates[fromCurrency][toCurrency] || 1;
}

function convertCurrency() {
    const fromCurrency = document.getElementById("fromCurrency").value;
    const toCurrency = document.getElementById("toCurrency").value;
    let amount = parseFloat(document.getElementById("amount").value);

    if (isNaN(amount)) {
        alert("Please enter a valid numeric amount.");
        return;
    }

    if (amount < 300) {
        alert("Minimum transaction amount is £300.");
        return;
    } else if (amount > 5000) {
        alert("Maximum transaction amount is £5000.");
        return;
    }

    const exchangeRate = getExchangeRate(fromCurrency, toCurrency);
    const convertedAmount = amount * exchangeRate;

    // Calculate fee based on the converted amount
    let feePercentage;
    if (amount <= 500) {
        feePercentage = 3.5;
    } else if (amount <= 1500) {
        feePercentage = 2.7;
    } else if (amount <= 2500) {
        feePercentage = 2.0;
    } else {
        feePercentage = 1.5;
    }

    const fee = (amount * feePercentage) / 100;

    // Display the currency conversion result and fee
    document.getElementById("result").innerHTML = `
        ${amount} ${fromCurrency} = ${convertedAmount.toFixed(2)} ${toCurrency}<br>
        <strong>Fee:</strong> ${fee.toFixed(2)} ${fromCurrency}
    `;
}