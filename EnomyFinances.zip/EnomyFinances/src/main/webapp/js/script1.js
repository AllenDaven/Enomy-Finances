//Alert message for login
function validateLoginForm() {
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    if (email === "" || password === "") {
        displayAlertMessage("Login Failed! Incorrect email or password.");
        return false;
    }

    return true;
}

function displayAlertMessage(message) {
    // Create a new alert message element
    var alertDiv = document.createElement("div");
    alertDiv.className = "alert";
    alertDiv.innerHTML = "<span class='closebtn' onclick='this.parentElement.style.display=\"none\";'>&times;</span>" + message;

    // Append the alert message element to the login form
    var loginForm = document.querySelector('.sign-in-form');
    loginForm.insertBefore(alertDiv, loginForm.firstChild);
}



//Alert message for register



//Login and Register
const sign_in_btn = document.querySelector("#sign-in-btn");
const sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");

sign_up_btn.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});