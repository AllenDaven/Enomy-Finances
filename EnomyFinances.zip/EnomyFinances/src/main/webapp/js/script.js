//Logout
document.addEventListener("DOMContentLoaded", function () {
    var logoutButton = document.getElementById("logoutButton");

    if (logoutButton) {
        logoutButton.addEventListener("click", function (event) {
            event.preventDefault();
            var confirmation = confirm("Are you sure you want to logout?");
            if (confirmation) {
                window.location.href = logoutButton.getAttribute("href");
            }
        });
    }
});


// Investment Calculator
document.getElementById("investmentForm").addEventListener("submit", function(event) {
    event.preventDefault();

    let initialAmount = parseFloat(document.getElementById("initialAmount").value);
    let monthlyInvestment = parseFloat(document.getElementById("monthlyInvestment").value);
    let investmentType = document.getElementById("investmentType").value;

    if (isNaN(initialAmount) || isNaN(monthlyInvestment)) {
        alert("Please enter valid numeric values for initial amount and monthly investment.");
        return;
    }

    let investmentValues = calculateInvestment(initialAmount, monthlyInvestment, investmentType);

    displayResults(investmentValues);
});

function calculateInvestment(initialAmount, monthlyInvestment, investmentType) {
    let investmentReturns = {
        'BasicSavingsPlan': {'1_year': 0.024, '5_years': 0.048, '10_years': 0.096},
        'SavingsPlanPlus': {'1_year': 0.055, '5_years': 0.083, '10_years': 0.11},
        'ManagedStockInvestments': {'1_year': 0.23, '5_years': 0.04, '10_years': 0.15}
    };

    let fees = {
        'BasicSavingsPlan': {'1_year': 25, '5_years': 50, '10_years': 100},
        'SavingsPlanPlus': {'1_year': 30, '5_years': 30, '10_years': 30},
        'ManagedStockInvestments': {'1_year': 130, '5_years': 130, '10_years': 130}
    };

    let taxes = {
        'BasicSavingsPlan': {'1_year': 0, '5_years': 0, '10_years': 0},
        'SavingsPlanPlus': {'1_year': 120, '5_years': 120, '10_years': 120},
        'ManagedStockInvestments': {'1_year': 120, '5_years': 200, '10_years': 200}
    };

    let investmentValues = {};
    for (let timeframe in investmentReturns[investmentType]) {
        let totalInvestment = initialAmount + (monthlyInvestment * 12 * parseInt(timeframe));
        let returns = totalInvestment * investmentReturns[investmentType][timeframe];
        let totalFees = fees[investmentType][timeframe];
        let totalTaxes = taxes[investmentType][timeframe];
        let totalProfit = returns - totalFees - totalTaxes;

        investmentValues[timeframe] = {
            'totalInvestment': totalInvestment.toFixed(2),
            'returns': returns.toFixed(2),
            'totalProfit': totalProfit.toFixed(2),
            'totalFees': totalFees.toFixed(2),
            'totalTaxes': totalTaxes.toFixed(2)
        };
    }

    return investmentValues;
}

function displayResults(investmentValues) {
    let resultsContainer = document.getElementById("resultsContainer");
    resultsContainer.innerHTML = "";

    for (let timeframe in investmentValues) {
        let div = document.createElement("div");
		div.innerHTML = `<h4>${timeframe.replace('_', ' ').toUpperCase()}</h4>`;
        div.innerHTML += `<p>Total Investment: &pound;${investmentValues[timeframe].totalInvestment}</p>`;
        div.innerHTML += `<p>Returns: &pound;${investmentValues[timeframe].returns}</p>`;
        div.innerHTML += `<p>Total Profit: &pound;${investmentValues[timeframe].totalProfit}</p>`;
        div.innerHTML += `<p>Total Fees: &pound;${investmentValues[timeframe].totalFees}</p>`;
        div.innerHTML += `<p>Total Taxes: &pound;${investmentValues[timeframe].totalTaxes}</p>`;

        resultsContainer.appendChild(div);
    }

    document.getElementById("investmentResults").classList.remove("hidden");
}


// Forgot Password
function resetPassword() {

    document.getElementById("resetMessage").innerText = "Password reset successful!";
}

